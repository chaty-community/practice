const api_server="http://localhost:3000";
const socket_server="http://localhost:8080";
export default {api_server,socket_server};